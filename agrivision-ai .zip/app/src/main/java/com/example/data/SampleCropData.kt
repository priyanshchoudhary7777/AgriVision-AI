package com.example.data

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.Base64
import com.example.data.blur.BlurDetector
import com.example.data.model.CapturedAngle
import com.example.data.model.PlantAngle
import java.io.ByteArrayOutputStream

object SampleCropData {

    fun createSampleAngle(angle: PlantAngle, isBlurry: Boolean = false): CapturedAngle {
        val width = 480
        val height = 480
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Background
        val bgPaint = Paint().apply { color = Color.rgb(240, 244, 240) }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        when (angle) {
            PlantAngle.LEAF_TOP -> {
                // Leaf body
                paint.color = Color.rgb(76, 175, 80)
                val leafPath = Path().apply {
                    moveTo(240f, 60f)
                    cubicTo(400f, 120f, 420f, 320f, 240f, 420f)
                    cubicTo(60f, 320f, 80f, 120f, 240f, 60f)
                    close()
                }
                canvas.drawPath(leafPath, paint)

                // Veins
                paint.color = Color.rgb(46, 125, 50)
                paint.strokeWidth = 5f
                paint.style = Paint.Style.STROKE
                canvas.drawLine(240f, 70f, 240f, 410f, paint)
                for (i in 1..5) {
                    val y = 100f + i * 50f
                    canvas.drawLine(240f, y, 340f, y - 30f, paint)
                    canvas.drawLine(240f, y, 140f, y - 30f, paint)
                }

                // Disease target lesions (Alternaria concentric spots)
                paint.style = Paint.Style.FILL
                val spotColors = listOf(Color.rgb(93, 64, 55), Color.rgb(141, 110, 99), Color.rgb(255, 235, 59))
                val spots = listOf(
                    Triple(200f, 180f, 32f),
                    Triple(290f, 240f, 40f),
                    Triple(180f, 290f, 26f)
                )
                for ((sx, sy, sr) in spots) {
                    paint.color = spotColors[2] // chlorotic yellow halo
                    canvas.drawCircle(sx, sy, sr + 12f, paint)
                    paint.color = spotColors[0] // dark brown necrosis
                    canvas.drawCircle(sx, sy, sr, paint)
                    paint.color = spotColors[1] // inner concentric ring
                    canvas.drawCircle(sx, sy, sr * 0.6f, paint)
                    paint.color = spotColors[0]
                    canvas.drawCircle(sx, sy, sr * 0.3f, paint)
                }
            }
            PlantAngle.LEAF_UNDERSIDE -> {
                // Paler green underside
                paint.color = Color.rgb(165, 214, 167)
                val leafPath = Path().apply {
                    moveTo(240f, 70f)
                    cubicTo(390f, 130f, 410f, 330f, 240f, 410f)
                    cubicTo(70f, 330f, 90f, 130f, 240f, 70f)
                    close()
                }
                canvas.drawPath(leafPath, paint)

                // Raised pale veins
                paint.color = Color.rgb(129, 199, 132)
                paint.strokeWidth = 7f
                paint.style = Paint.Style.STROKE
                canvas.drawLine(240f, 80f, 240f, 400f, paint)

                // Powdery/downy velvety spores
                paint.style = Paint.Style.FILL
                paint.color = Color.rgb(238, 238, 238)
                val sporeCenters = listOf(Pair(220f, 200f), Pair(260f, 220f), Pair(210f, 280f), Pair(270f, 310f))
                for ((cx, cy) in sporeCenters) {
                    for (j in 0..12) {
                        val dx = (Math.random() * 40 - 20).toFloat()
                        val dy = (Math.random() * 40 - 20).toFloat()
                        canvas.drawCircle(cx + dx, cy + dy, 4f, paint)
                    }
                }
            }
            PlantAngle.STEM_BASE -> {
                // Soil at bottom
                paint.color = Color.rgb(110, 80, 50)
                canvas.drawRect(0f, 360f, width.toFloat(), height.toFloat(), paint)

                // Stem trunk
                paint.color = Color.rgb(102, 187, 106)
                canvas.drawRect(200f, 60f, 280f, 370f, paint)

                // Collar lesion (dark canker water-soaked)
                paint.color = Color.rgb(62, 39, 35)
                canvas.drawRoundRect(195f, 300f, 285f, 370f, 10f, 10f, paint)
                paint.color = Color.rgb(198, 40, 40)
                canvas.drawCircle(240f, 335f, 12f, paint)
            }
            PlantAngle.FRUIT_FLOWER -> {
                // Tomato fruit
                paint.color = Color.rgb(229, 57, 53)
                canvas.drawCircle(240f, 240f, 120f, paint)

                // Blossom-end rot spot
                paint.color = Color.rgb(38, 50, 56)
                canvas.drawCircle(240f, 330f, 35f, paint)

                // Calyx green top
                paint.color = Color.rgb(46, 125, 50)
                paint.strokeWidth = 6f
                paint.style = Paint.Style.STROKE
                canvas.drawLine(240f, 120f, 240f, 80f, paint)
                canvas.drawLine(240f, 120f, 180f, 100f, paint)
                canvas.drawLine(240f, 120f, 300f, 100f, paint)
            }
            PlantAngle.WIDE_CANOPY -> {
                // Overall plant stake and foliage
                paint.color = Color.rgb(121, 85, 72)
                paint.strokeWidth = 10f
                paint.style = Paint.Style.STROKE
                canvas.drawLine(240f, 40f, 240f, 440f, paint)

                paint.style = Paint.Style.FILL
                paint.color = Color.rgb(56, 142, 60)
                canvas.drawCircle(190f, 160f, 50f, paint)
                canvas.drawCircle(290f, 170f, 55f, paint)
                canvas.drawCircle(180f, 260f, 65f, paint)
                canvas.drawCircle(295f, 270f, 60f, paint)

                // Chlorotic yellow lower branches
                paint.color = Color.rgb(251, 192, 45)
                canvas.drawCircle(170f, 350f, 55f, paint)
                canvas.drawCircle(300f, 360f, 55f, paint)
            }
        }

        val finalBitmap = if (isBlurry) {
            // Apply slight box blur by downscaling and upscaling smoothly
            val tiny = Bitmap.createScaledBitmap(bitmap, 40, 40, true)
            Bitmap.createScaledBitmap(tiny, width, height, true)
        } else {
            bitmap
        }

        val quality = BlurDetector.analyzeQuality(finalBitmap)
        val base64 = finalBitmap.toBase64()

        return CapturedAngle(
            angle = angle,
            imagePath = null,
            base64Data = base64,
            qualityCheck = quality
        )
    }

    private fun Bitmap.toBase64(): String {
        val stream = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.JPEG, 85, stream)
        val byteArray = stream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }
}
