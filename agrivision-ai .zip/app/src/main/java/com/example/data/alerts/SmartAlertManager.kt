package com.example.data.alerts

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R

class SmartAlertManager(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "agrivision_weather_alerts"
        const val CHANNEL_NAME = "AgriVision Plant & Weather Alerts"
        const val NOTIFICATION_ID_RAIN = 1001
        const val NOTIFICATION_ID_SPRAY = 1002
        const val NOTIFICATION_ID_DISEASE = 1003
    }

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = "Timely agricultural alerts for rain, irrigation adjustments, and spray windows"
                enableVibration(true)
            }
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun sendRainIrrigationAlert(rainForecastMm: Double, precipProb: Int) {
        val title = "🌧️ Weather Alert: Skip Irrigation Today!"
        val content = "Rain forecast (${rainForecastMm}mm, $precipProb% chance). Skip watering to prevent root rot & fungal spore splash."
        showNotification(NOTIFICATION_ID_RAIN, title, content)
    }

    fun sendOptimalSprayAlert(sprayWindowTime: String) {
        val title = "🌱 Optimal Spray Window Detected"
        val content = "Calm winds and dry canopy detected. Best spray window: $sprayWindowTime."
        showNotification(NOTIFICATION_ID_SPRAY, title, content)
    }

    fun sendDiseaseOutbreakWarning(disease: String, severity: String) {
        val title = "⚠️ Spore Proliferation Alert: $disease"
        val content = "Current heat and humidity exceed safe thresholds. Immediate inspection recommended."
        showNotification(NOTIFICATION_ID_DISEASE, title, content)
    }

    private fun showNotification(id: Int, title: String, content: String) {
        try {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                id,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
            )

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle(title)
                .setContentText(content)
                .setStyle(NotificationCompat.BigTextStyle().bigText(content))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            val notificationManager = NotificationManagerCompat.from(context)
            // If POST_NOTIFICATIONS is not granted on API 33+, this may catch SecurityException gracefully
            notificationManager.notify(id, builder.build())
        } catch (e: SecurityException) {
            // Permission not yet granted by user, gracefully ignored
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
