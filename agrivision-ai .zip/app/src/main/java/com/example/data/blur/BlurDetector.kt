package com.example.data.blur

import android.graphics.Bitmap
import com.example.data.model.BlurQuality
import com.example.data.model.QualityCheckResult
import kotlin.math.max
import kotlin.math.min

object BlurDetector {

    /**
     * Performs fast on-device blur detection and lighting exposure check
     * using Laplacian operator variance on luminance pixels.
     */
    fun analyzeQuality(bitmap: Bitmap): QualityCheckResult {
        // Downsample for high-speed computation (maintains edge frequency while being 50x faster)
        val targetWidth = 240
        val targetHeight = (bitmap.height * (targetWidth.toFloat() / bitmap.width)).toInt().coerceIn(160, 320)
        val scaled = Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)

        val width = scaled.width
        val height = scaled.height
        val pixels = IntArray(width * height)
        scaled.getPixels(pixels, 0, width, 0, 0, width, height)

        // Convert to grayscale luminance
        val gray = IntArray(width * height)
        var totalLuminance = 0L

        for (i in pixels.indices) {
            val pixel = pixels[i]
            val r = (pixel shr 16) and 0xFF
            val g = (pixel shr 8) and 0xFF
            val b = pixel and 0xFF
            val lum = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
            gray[i] = lum
            totalLuminance += lum
        }

        val avgBrightness = (totalLuminance / (width * height)).toInt()
        val brightnessPercent = ((avgBrightness / 255.0) * 100).toInt().coerceIn(0, 100)

        // Compute discrete Laplacian: L(x,y) = 4*I(x,y) - I(x+1,y) - I(x-1,y) - I(x,y+1) - I(x,y-1)
        var sumLaplacian = 0.0
        var sumLaplacianSq = 0.0
        var count = 0

        for (y in 1 until height - 1) {
            val rowOffset = y * width
            for (x in 1 until width - 1) {
                val center = gray[rowOffset + x]
                val top = gray[rowOffset - width + x]
                val bottom = gray[rowOffset + width + x]
                val left = gray[rowOffset + x - 1]
                val right = gray[rowOffset + x + 1]

                val lap = (4 * center - top - bottom - left - right)
                sumLaplacian += lap
                sumLaplacianSq += (lap * lap)
                count++
            }
        }

        val mean = if (count > 0) sumLaplacian / count else 0.0
        val variance = if (count > 0) (sumLaplacianSq / count) - (mean * mean) else 0.0

        // Normalizing variance into 0..100 sharpness score
        // Typically variance < 100 is blurry, 100-250 is moderate/acceptable, > 250 is sharp
        val normalizedSharpness = min(100, max(0, (variance / 4.0).toInt()))

        val quality = when {
            variance >= 180.0 -> BlurQuality.SHARP
            variance >= 90.0 -> BlurQuality.ACCEPTABLE
            else -> BlurQuality.BLURRY
        }

        val lightingAdvice = when {
            brightnessPercent < 25 -> "Image too dark. Increase lighting or avoid shadow."
            brightnessPercent > 88 -> "Image overexposed. Move away from harsh glare."
            quality == BlurQuality.BLURRY -> "Motion blur detected. Hold phone steady and tap to focus."
            quality == BlurQuality.ACCEPTABLE -> "Clear enough for AI, but steady hands ensure best results."
            else -> "Optimal clarity & illumination. High diagnosis confidence expected."
        }

        if (scaled != bitmap) {
            scaled.recycle()
        }

        return QualityCheckResult(
            varianceScore = variance,
            sharpnessPercent = normalizedSharpness,
            quality = quality,
            brightnessPercent = brightnessPercent,
            lightingAdvice = lightingAdvice
        )
    }
}
