package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scan_records")
data class ScanRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val plantName: String,
    val diseaseName: String,
    val diseaseNameHindi: String,
    val confidencePercent: Int,
    val severity: String,
    val pathogenCategory: String,
    val temperature: Double,
    val humidity: Int,
    val weatherCondition: String,
    val rainForecastMm: Double,
    val irrigationAdvice: String,
    val irrigationAdviceHindi: String,
    val sprayRecommendation: String,
    val remediesJson: String, // comma or newline separated
    val observationsJson: String,
    val anglesCount: Int,
    val timestamp: Long = System.currentTimeMillis()
)
