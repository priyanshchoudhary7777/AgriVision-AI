package com.example.data.database

import kotlinx.coroutines.flow.Flow

class ScanRecordRepository(private val dao: ScanRecordDao) {

    val allScans: Flow<List<ScanRecordEntity>> = dao.getAllScans()

    suspend fun insertScan(scan: ScanRecordEntity): Long = dao.insertScan(scan)

    suspend fun getScanById(id: Long): ScanRecordEntity? = dao.getScanById(id)

    suspend fun deleteScanById(id: Long) = dao.deleteScanById(id)

    suspend fun clearAll() = dao.clearAll()
}
