package com.example.data.model

data class CarePlan(
    val irrigationAdvice: String,
    val irrigationAdviceHindi: String,
    val sprayWindowRecommendation: String,
    val organicRemedies: List<String>,
    val chemicalTreatments: List<String>,
    val preventativeMeasures: List<String>,
    val alertWarning: String? = null
)

enum class DiseaseSeverity(val label: String, val colorHex: Long) {
    HEALTHY("Healthy Plant", 0xFF2D6A4F),
    LOW("Low Severity (Early Stage)", 0xFF52B788),
    MODERATE("Moderate Severity", 0xFFF4A261),
    SEVERE("High Severity (Intervene Now)", 0xFFE76F51),
    CRITICAL("Critical Outbreak Risk", 0xFFD90429)
}

data class DiagnosisResult(
    val plantName: String,
    val primaryDisease: String,
    val primaryDiseaseHindi: String,
    val confidencePercent: Int,
    val severity: DiseaseSeverity,
    val pathogenCategory: String, // Fungal, Bacterial, Viral, Pest, Deficiency, Environmental
    val keyObservations: List<String>,
    val weatherRiskFusion: String,
    val carePlan: CarePlan,
    val anglesAnalyzedCount: Int = 3
)

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val isFromUser: Boolean,
    val textEnglish: String,
    val textHindi: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
