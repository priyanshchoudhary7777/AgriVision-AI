package com.example.data.model

enum class PlantAngle(
    val id: String,
    val title: String,
    val titleHindi: String,
    val instructions: String,
    val guidanceTip: String,
    val isRequired: Boolean = true
) {
    LEAF_TOP(
        id = "leaf_top",
        title = "Leaf Top",
        titleHindi = "पत्ती का ऊपरी भाग",
        instructions = "Capture the upper surface showing spots, yellowing, or lesions.",
        guidanceTip = "Hold 15-20cm away in daylight; focus on discolored margins."
    ),
    LEAF_UNDERSIDE(
        id = "leaf_underside",
        title = "Leaf Underside",
        titleHindi = "पत्ती का निचला भाग",
        instructions = "Flip leaf gently to check for spores, aphids, mites, or mold.",
        guidanceTip = "Crucial for early detection of Downy Mildew and Spider Mites."
    ),
    STEM_BASE(
        id = "stem_base",
        title = "Stem & Root Base",
        titleHindi = "तना और जड़ का आधार",
        instructions = "Inspect the lower stem, soil boundary, or crown for rot and cankers.",
        guidanceTip = "Detects damping-off, collar rot, and bacterial wilt vascular browning."
    ),
    FRUIT_FLOWER(
        id = "fruit_flower",
        title = "Fruit / Flower",
        titleHindi = "फल या फूल",
        instructions = "Capture blossoms, budding pods, or fruit showing rot or pest bites.",
        guidanceTip = "Essential for blossom-end rot, fruit borers, and anthracnose.",
        isRequired = false
    ),
    WIDE_CANOPY(
        id = "wide_canopy",
        title = "Whole Canopy Context",
        titleHindi = "पूरे पौधे का दृश्य",
        instructions = "Step back 1 meter to capture overall plant vigor, wilting, or stunt.",
        guidanceTip = "Gives AI context on nutrient deficiency versus localized infection.",
        isRequired = false
    )
}

enum class BlurQuality(val label: String, val isAcceptable: Boolean) {
    SHARP("Sharp & Clear", true),
    ACCEPTABLE("Acceptable Clarity", true),
    BLURRY("Blurry - Retake Recommended", false)
}

data class QualityCheckResult(
    val varianceScore: Double,
    val sharpnessPercent: Int,
    val quality: BlurQuality,
    val brightnessPercent: Int,
    val lightingAdvice: String
)

data class CapturedAngle(
    val angle: PlantAngle,
    val imagePath: String? = null,
    val base64Data: String? = null,
    val qualityCheck: QualityCheckResult? = null,
    val timestamp: Long = System.currentTimeMillis()
)
