package com.example.data.model

data class WeatherInfo(
    val temperatureCelsius: Double = 27.5,
    val humidityPercent: Int = 82,
    val weatherCondition: String = "Scattered Showers Expected",
    val precipitationChance: Int = 75,
    val rainForecastNext24hMm: Double = 14.2,
    val windSpeedKmh: Double = 11.0,
    val latitude: Double = 28.6139,
    val longitude: Double = 77.2090,
    val locationName: String = "Agronomy Zone (GPS Linked)",
    val timestamp: Long = System.currentTimeMillis()
) {
    val isHighDiseaseRisk: Boolean
        get() = humidityPercent > 70 && temperatureCelsius in 18.0..32.0

    val shouldSkipWatering: Boolean
        get() = precipitationChance > 50 || rainForecastNext24hMm > 5.0

    val sprayWindowRecommendation: String
        get() = when {
            precipitationChance > 40 -> "DO NOT SPRAY: Rain forecast within next hours will wash off agrochemicals."
            windSpeedKmh > 15.0 -> "CAUTION: Wind speed (${windSpeedKmh.toInt()} km/h) exceeds safe drift limits."
            temperatureCelsius > 32.0 -> "DELAY: Apply in early morning or evening to avoid leaf scorch."
            else -> "OPTIMAL WINDOW: Calm winds, dry foliage. Ideal for spray application."
        }
}
