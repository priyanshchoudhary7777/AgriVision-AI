package com.example.data.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class VoiceAssistantManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private val _engineStatus = MutableStateFlow(VoiceEngineStatus.INITIALIZING)
    val engineStatus: StateFlow<VoiceEngineStatus> = _engineStatus.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _speechInput = MutableStateFlow<String?>(null)
    val speechInput: StateFlow<String?> = _speechInput.asStateFlow()

    private val _partialSpeechInput = MutableStateFlow<String?>(null)
    val partialSpeechInput: StateFlow<String?> = _partialSpeechInput.asStateFlow()

    private val _rmsDb = MutableStateFlow(0.0f)
    val rmsDb: StateFlow<Float> = _rmsDb.asStateFlow()

    private val _speechError = MutableStateFlow<String?>(null)
    val speechError: StateFlow<String?> = _speechError.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(VoiceLanguages.ENGLISH)
    val selectedLanguage: StateFlow<SupportedVoiceLanguage> = _selectedLanguage.asStateFlow()

    private val _speechRate = MutableStateFlow(TtsSpeechRate.NORMAL)
    val speechRate: StateFlow<TtsSpeechRate> = _speechRate.asStateFlow()

    private var lastSpokenText: String? = null
    private var speechRecognizer: SpeechRecognizer? = null

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("VoiceAssistant", "Error constructing TextToSpeech", e)
            _engineStatus.value = VoiceEngineStatus.ERROR
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            _engineStatus.value = VoiceEngineStatus.READY
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                    _engineStatus.value = VoiceEngineStatus.SPEAKING
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    _engineStatus.value = VoiceEngineStatus.READY
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    _engineStatus.value = VoiceEngineStatus.READY
                }
            })
        } else {
            Log.e("VoiceAssistant", "Failed to initialize TextToSpeech: status=$status")
            _engineStatus.value = VoiceEngineStatus.ERROR
        }
    }

    fun setLanguage(language: SupportedVoiceLanguage) {
        _selectedLanguage.value = language
    }

    fun setSpeechRate(rate: TtsSpeechRate) {
        _speechRate.value = rate
    }

    fun speak(text: String, language: SupportedVoiceLanguage? = null) {
        if (!isTtsReady || tts == null) {
            Log.w("VoiceAssistant", "TTS engine not ready yet")
            return
        }

        val targetLang = language ?: _selectedLanguage.value
        lastSpokenText = text

        try {
            stopSpeaking()

            val locale = targetLang.locale
            val availability = tts?.isLanguageAvailable(locale) ?: TextToSpeech.LANG_NOT_SUPPORTED
            if (availability == TextToSpeech.LANG_MISSING_DATA || availability == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to Hindi if target was an Indic language, or English
                val fallbackLocale = if (targetLang.code.endsWith("-IN") && targetLang.code != "en-US") {
                    Locale.forLanguageTag("hi-IN")
                } else {
                    Locale.US
                }
                tts?.setLanguage(fallbackLocale)
            } else {
                tts?.setLanguage(locale)
            }

            tts?.setPitch(1.0f)
            tts?.setSpeechRate(_speechRate.value.speedMultiplier)

            val utteranceId = "AgriVisionTTS_${System.currentTimeMillis()}"
            _isSpeaking.value = true
            _engineStatus.value = VoiceEngineStatus.SPEAKING
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        } catch (e: Exception) {
            Log.e("VoiceAssistant", "TTS speak error: ${e.message}")
            _isSpeaking.value = false
            _engineStatus.value = VoiceEngineStatus.READY
        }
    }

    fun repeatLastSpoken() {
        lastSpokenText?.let { speak(it) }
    }

    fun stopSpeaking() {
        try {
            tts?.stop()
            _isSpeaking.value = false
            if (_engineStatus.value == VoiceEngineStatus.SPEAKING) {
                _engineStatus.value = VoiceEngineStatus.READY
            }
        } catch (e: Exception) {
            Log.e("VoiceAssistant", "TTS stop error: ${e.message}")
        }
    }

    fun isSpeechRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    fun createSpeechRecognizerIntent(language: SupportedVoiceLanguage = _selectedLanguage.value): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language.code)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language.code)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(
                RecognizerIntent.EXTRA_PROMPT,
                "AgriVision Voice: ${language.displayName} (${language.nativeLabel})"
            )
        }
    }

    fun startListening(
        language: SupportedVoiceLanguage = _selectedLanguage.value,
        onFinalResult: (String) -> Unit
    ) {
        if (!isSpeechRecognitionAvailable()) {
            _speechError.value = "Direct speech recognition service not found on this device."
            return
        }

        try {
            stopListening()
            stopSpeaking()
            vibrateFeedback()

            _speechError.value = null
            _partialSpeechInput.value = null
            _speechInput.value = null
            _rmsDb.value = 0f

            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _isListening.value = true
                        _engineStatus.value = VoiceEngineStatus.LISTENING
                    }

                    override fun onBeginningOfSpeech() {
                        _engineStatus.value = VoiceEngineStatus.LISTENING
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        // Normalize RMS dB typically in [-2, 10] range
                        _rmsDb.value = rmsdB.coerceIn(0f, 10f)
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _isListening.value = false
                        _rmsDb.value = 0f
                        _engineStatus.value = VoiceEngineStatus.READY
                    }

                    override fun onError(error: Int) {
                        _isListening.value = false
                        _rmsDb.value = 0f
                        _engineStatus.value = VoiceEngineStatus.READY
                        val message = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech detected. Please speak closer to microphone."
                            SpeechRecognizer.ERROR_NETWORK -> "Network issue while processing speech."
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Voice network request timed out."
                            SpeechRecognizer.ERROR_AUDIO -> "Audio recording issue. Please check microphone."
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Audio record permission needed."
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech heard. Tap mic and try again."
                            else -> "Voice recognition interrupted ($error)."
                        }
                        _speechError.value = message
                    }

                    override fun onResults(results: Bundle?) {
                        _isListening.value = false
                        _rmsDb.value = 0f
                        _engineStatus.value = VoiceEngineStatus.READY
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val bestResult = matches?.firstOrNull()
                        if (!bestResult.isNullOrBlank()) {
                            _speechInput.value = bestResult
                            _partialSpeechInput.value = null
                            vibrateFeedback()
                            onFinalResult(bestResult)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val interim = matches?.firstOrNull()
                        if (!interim.isNullOrBlank()) {
                            _partialSpeechInput.value = interim
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = createSpeechRecognizerIntent(language)
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.e("VoiceAssistant", "Speech recognition failed to start", e)
            _isListening.value = false
            _speechError.value = e.message
            _engineStatus.value = VoiceEngineStatus.READY
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
            speechRecognizer = null
            _isListening.value = false
            _rmsDb.value = 0f
            if (_engineStatus.value == VoiceEngineStatus.LISTENING) {
                _engineStatus.value = VoiceEngineStatus.READY
            }
        } catch (e: Exception) {
            Log.w("VoiceAssistant", "Stop listening error: ${e.message}")
        }
    }

    fun clearSpeechState() {
        _speechInput.value = null
        _partialSpeechInput.value = null
        _speechError.value = null
        _rmsDb.value = 0f
    }

    private fun vibrateFeedback() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                vibrator?.vibrate(35)
            }
        } catch (_: Exception) {
            // Non-critical haptic feedback
        }
    }

    fun shutdown() {
        stopSpeaking()
        stopListening()
        tts?.shutdown()
        tts = null
    }
}
