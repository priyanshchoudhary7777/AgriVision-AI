package com.example.data.voice

import java.util.Locale

data class SupportedVoiceLanguage(
    val code: String,
    val displayName: String,
    val nativeLabel: String,
    val locale: Locale,
    val samplePrompts: List<String>
)

object VoiceLanguages {
    val ENGLISH = SupportedVoiceLanguage(
        code = "en-US",
        displayName = "English",
        nativeLabel = "English",
        locale = Locale.US,
        samplePrompts = listOf(
            "Should I skip watering today?",
            "What is the best spray window?",
            "Is Neem oil spray effective for this?",
            "How to protect neighboring crops?"
        )
    )

    val HINDI = SupportedVoiceLanguage(
        code = "hi-IN",
        displayName = "Hindi",
        nativeLabel = "हिन्दी",
        locale = Locale.forLanguageTag("hi-IN"),
        samplePrompts = listOf(
            "क्या आज सिंचाई छोड़ देनी चाहिए?",
            "दवा छिड़काव का सही समय क्या है?",
            "नीम के तेल का सही अनुपात बताएं?",
            "इस रोग से अन्य पौधों को कैसे बचाएं?"
        )
    )

    val PUNJABI = SupportedVoiceLanguage(
        code = "pa-IN",
        displayName = "Punjabi",
        nativeLabel = "ਪੰਜਾਬੀ",
        locale = Locale.forLanguageTag("pa-IN"),
        samplePrompts = listOf(
            "ਕੀ ਅੱਜ ਪਾਣੀ ਦੇਣਾ ਛੱਡ ਦੇਣਾ ਚਾਹੀਦਾ ਹੈ?",
            "ਸਪਰੇਅ ਕਰਨ ਦਾ ਸਹੀ ਸਮਾਂ ਕੀ ਹੈ?",
            "ਨੀਮ ਦੇ ਤੇਲ ਦੀ ਸਹੀ ਮਾਤਰਾ ਦੱਸੋ?",
            "ਦੂਜੀਆਂ ਫਸਲਾਂ ਨੂੰ ਕਿਵੇਂ ਬਚਾਇਆ ਜਾਵੇ?"
        )
    )

    val MARATHI = SupportedVoiceLanguage(
        code = "mr-IN",
        displayName = "Marathi",
        nativeLabel = "मराठी",
        locale = Locale.forLanguageTag("mr-IN"),
        samplePrompts = listOf(
            "आज पाणी देणे टाळावे का?",
            "फवारणीसाठी योग्य वेळ कोणती?",
            "कडुनिंब तेलाचे प्रमाण किती ठेवावे?",
            "इतर पिकांना रोगापासून कसे वाचवायचे?"
        )
    )

    val TELUGU = SupportedVoiceLanguage(
        code = "te-IN",
        displayName = "Telugu",
        nativeLabel = "తెలుగు",
        locale = Locale.forLanguageTag("te-IN"),
        samplePrompts = listOf(
            "ఈరోజు నీరు పెట్టడం ఆపాలా?",
            "మందు పిచிகారీ చేయడానికి సరైన సమయం ఏది?",
            "వేప నూనె ఎంత మోతాదులో వాడాలి?",
            "మిగతా పంటలను ఎలా కాపాడుకోవాలి?"
        )
    )

    val TAMIL = SupportedVoiceLanguage(
        code = "ta-IN",
        displayName = "Tamil",
        nativeLabel = "தமிழ்",
        locale = Locale.forLanguageTag("ta-IN"),
        samplePrompts = listOf(
            "இன்று தண்ணீர் பாய்ச்சுவதை தவிர்க்க வேண்டுமா?",
            "மருந்து தெளிக்க சரியான நேரம் எது?",
            "வேப்பெண்ணெய் கரைசல் அளவு என்ன?",
            "மற்ற பயிர்களை எப்படி பாதுகாப்பது?"
        )
    )

    val GUJARATI = SupportedVoiceLanguage(
        code = "gu-IN",
        displayName = "Gujarati",
        nativeLabel = "ગુજરાતી",
        locale = Locale.forLanguageTag("gu-IN"),
        samplePrompts = listOf(
            "શું આજે પિયત આપવાનું ટાળવું જોઈએ?",
            "દવા છંટકાવનો શ્રેષ્ઠ સમય કયો છે?",
            "લીમડાના તેલનું પ્રમાણ કેટલું રાખવું?",
            "અન્ય પાકોને કેવી રીતે બચાવવા?"
        )
    )

    val BENGALI = SupportedVoiceLanguage(
        code = "bn-IN",
        displayName = "Bengali",
        nativeLabel = "বাংলা",
        locale = Locale.forLanguageTag("bn-IN"),
        samplePrompts = listOf(
            "আজ কি সেচ দেওয়া বন্ধ রাখা উচিত?",
            "কীটনাশক স্প্রে করার সঠিক সময় কোনটি?",
            "নিম তেলের সঠিক মাত্রা কতটা?",
            "অন্যান্য গাছকে কীভাবে বাঁচাব?"
        )
    )

    val ALL_LANGUAGES = listOf(
        ENGLISH,
        HINDI,
        PUNJABI,
        MARATHI,
        TELUGU,
        TAMIL,
        GUJARATI,
        BENGALI
    )
}

enum class TtsSpeechRate(val label: String, val speedMultiplier: Float) {
    SLOW("0.8x (Clear)", 0.82f),
    NORMAL("1.0x (Normal)", 0.95f),
    FAST("1.2x (Fast)", 1.2f)
}

enum class VoiceEngineStatus(val label: String) {
    INITIALIZING("Setting up voice engine..."),
    READY("Voice engine active"),
    LISTENING("Listening to voice..."),
    SPEAKING("Speaking answer aloud..."),
    ERROR("Voice service notice")
}
