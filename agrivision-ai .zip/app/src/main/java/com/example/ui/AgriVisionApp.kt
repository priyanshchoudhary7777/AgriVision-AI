package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Healing
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.SuaaAppHeader
import com.example.ui.screens.ActScreen
import com.example.ui.screens.AskScreen
import com.example.ui.screens.OfflineHistoryScreen
import com.example.ui.screens.SeeScreen
import com.example.ui.screens.UnderstandScreen
import com.example.ui.theme.AgriGold
import com.example.ui.theme.AgriGreenDark
import com.example.ui.theme.AgriGreenPale
import com.example.ui.theme.AgriGreenPrimary
import com.example.ui.theme.AgriRedAlert
import com.example.ui.theme.ThemeMode

@Composable
fun AgriVisionApp(viewModel: MainViewModel = viewModel()) {
    val currentTab by viewModel.currentTab.collectAsState()
    val capturedAngles by viewModel.capturedAngles.collectAsState()
    val selectedAngle by viewModel.selectedAngle.collectAsState()
    val weather by viewModel.weatherInfo.collectAsState()
    val isWeatherLoading by viewModel.isWeatherLoading.collectAsState()
    val isAnalyzing by viewModel.isAnalyzing.collectAsState()
    val diagnosis by viewModel.diagnosisResult.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isHindi by viewModel.isHindiPreferred.collectAsState()
    val userNotice by viewModel.userFeedbackNotice.collectAsState()
    val savedScans by viewModel.savedScans.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()

    val isSpeaking by viewModel.voiceManager.isSpeaking.collectAsState()
    val isListening by viewModel.voiceManager.isListening.collectAsState()
    val selectedVoiceLanguage by viewModel.selectedVoiceLanguage.collectAsState()
    val speechRate by viewModel.ttsSpeechRate.collectAsState()
    val voiceEngineStatus by viewModel.voiceEngineStatus.collectAsState()
    val rmsDb by viewModel.rmsDb.collectAsState()
    val partialSpeechInput by viewModel.partialSpeechInput.collectAsState()
    val speechError by viewModel.speechError.collectAsState()

    val isDark = isSystemInDarkTheme() || themeMode == ThemeMode.DARK

    Scaffold(
        topBar = {
            Column(modifier = Modifier.statusBarsPadding()) {
                SuaaAppHeader(
                    currentTab = currentTab,
                    isHindi = isHindi,
                    onToggleLanguage = { viewModel.toggleLanguage() },
                    themeMode = themeMode,
                    onCycleThemeMode = { viewModel.cycleThemeMode() },
                    weather = weather,
                    isWeatherLoading = isWeatherLoading,
                    onRefreshWeather = { viewModel.refreshWeather() }
                )

                // Feedback Banner
                AnimatedVisibility(
                    visible = userNotice != null,
                    enter = slideInVertically() + fadeIn(),
                    exit = slideOutVertically() + fadeOut()
                ) {
                    userNotice?.let { notice ->
                        val bannerBg = if (notice.contains("⚠️")) {
                            if (isDark) Color(0xFF3B2A05) else Color(0xFFFFF3CD)
                        } else {
                            if (isDark) Color(0xFF143021) else AgriGreenDark
                        }
                        val bannerText = if (notice.contains("⚠️")) {
                            if (isDark) AgriGold else Color(0xFF856404)
                        } else {
                            if (isDark) AgriGreenPale else Color.White
                        }

                        Surface(
                            color = bannerBg,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = null,
                                        tint = bannerText,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = notice,
                                        color = bannerText,
                                        fontSize = 12.sp,
                                        maxLines = 2
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.clearFeedbackNotice() },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Dismiss",
                                        tint = bannerText,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            val navItemColors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            )

            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("suaa_navigation_bar")
            ) {
                // Tab 1: SEE
                NavigationBarItem(
                    selected = currentTab == SuaaTab.SEE,
                    onClick = { viewModel.setTab(SuaaTab.SEE) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (capturedAngles.isNotEmpty()) {
                                    Badge(containerColor = MaterialTheme.colorScheme.primary) {
                                        Text("${capturedAngles.size}")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "See - Multi-angle camera"
                            )
                        }
                    },
                    label = { Text(if (isHindi) "देखें" else "See", fontSize = 11.sp) },
                    colors = navItemColors,
                    modifier = Modifier.testTag("nav_tab_see")
                )

                // Tab 2: UNDERSTAND
                NavigationBarItem(
                    selected = currentTab == SuaaTab.UNDERSTAND,
                    onClick = { viewModel.setTab(SuaaTab.UNDERSTAND) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = "Understand - AI Reasoning"
                        )
                    },
                    label = { Text(if (isHindi) "समझें" else "Understand", fontSize = 11.sp) },
                    colors = navItemColors,
                    modifier = Modifier.testTag("nav_tab_understand")
                )

                // Tab 3: ACT
                NavigationBarItem(
                    selected = currentTab == SuaaTab.ACT,
                    onClick = { viewModel.setTab(SuaaTab.ACT) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Healing,
                            contentDescription = "Act - Care Plan"
                        )
                    },
                    label = { Text(if (isHindi) "कार्य" else "Act", fontSize = 11.sp) },
                    colors = navItemColors,
                    modifier = Modifier.testTag("nav_tab_act")
                )

                // Tab 4: ASK
                NavigationBarItem(
                    selected = currentTab == SuaaTab.ASK,
                    onClick = { viewModel.setTab(SuaaTab.ASK) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Ask - Voice Assistant"
                        )
                    },
                    label = { Text(if (isHindi) "पूछें" else "Ask", fontSize = 11.sp) },
                    colors = navItemColors,
                    modifier = Modifier.testTag("nav_tab_ask")
                )

                // Tab 5: OFFLINE / HISTORY
                NavigationBarItem(
                    selected = currentTab == SuaaTab.HISTORY,
                    onClick = { viewModel.setTab(SuaaTab.HISTORY) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (savedScans.isNotEmpty()) {
                                    Badge(containerColor = MaterialTheme.colorScheme.primary) {
                                        Text("${savedScans.size}")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudOff,
                                contentDescription = "Offline Cache & History"
                            )
                        }
                    },
                    label = { Text(if (isHindi) "ऑफ़लाइन" else "Offline", fontSize = 11.sp) },
                    colors = navItemColors,
                    modifier = Modifier.testTag("nav_tab_history")
                )
            }
        }

    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (currentTab) {
                SuaaTab.SEE -> {
                    SeeScreen(
                        capturedAngles = capturedAngles,
                        selectedAngle = selectedAngle,
                        onSelectAngle = { viewModel.selectAngle(it) },
                        onImageCaptured = { angle, bitmap -> viewModel.onImageCaptured(angle, bitmap) },
                        onImageSelected = { angle, uri -> viewModel.onUriImageSelected(angle, uri) },
                        onRemoveAngle = { viewModel.removeCapturedAngle(it) },
                        onLoadDemoSamples = { viewModel.loadSampleAngles() },
                        onRunAnalysis = { viewModel.runUnderstandAnalysis() },
                        isAnalyzing = isAnalyzing,
                        isHindi = isHindi
                    )
                }
                SuaaTab.UNDERSTAND -> {
                    UnderstandScreen(
                        diagnosis = diagnosis,
                        weather = weather,
                        onRefreshWeather = { viewModel.refreshWeather() },
                        onNavigateToAct = { viewModel.setTab(SuaaTab.ACT) },
                        onBackToCapture = { viewModel.setTab(SuaaTab.SEE) },
                        isHindi = isHindi
                    )
                }
                SuaaTab.ACT -> {
                    ActScreen(
                        diagnosis = diagnosis,
                        weather = weather,
                        onTriggerNotification = { viewModel.triggerSmartNotification() },
                        onNavigateToAsk = { viewModel.setTab(SuaaTab.ASK) },
                        isHindi = isHindi
                    )
                }
                SuaaTab.ASK -> {
                    AskScreen(
                        chatMessages = chatMessages,
                        onSendMessage = { viewModel.sendVoiceOrTextMessage(it) },
                        onSpeakMessage = { viewModel.speakMessage(it) },
                        onStopSpeaking = { viewModel.voiceManager.stopSpeaking() },
                        onRepeatLastSpoken = { viewModel.voiceManager.repeatLastSpoken() },
                        isSpeaking = isSpeaking,
                        isListening = isListening,
                        rmsDb = rmsDb,
                        partialSpeechText = partialSpeechInput,
                        speechError = speechError,
                        onToggleListening = {
                            if (isListening) {
                                viewModel.voiceManager.stopListening()
                            } else {
                                viewModel.voiceManager.startListening(language = selectedVoiceLanguage) { recognizedText ->
                                    viewModel.sendVoiceOrTextMessage(recognizedText)
                                }
                            }
                        },
                        selectedLanguage = selectedVoiceLanguage,
                        onSelectLanguage = { viewModel.selectVoiceLanguage(it) },
                        speechRate = speechRate,
                        onSelectSpeechRate = { viewModel.setTtsSpeechRate(it) },
                        engineStatus = voiceEngineStatus,
                        activeDiagnosis = diagnosis
                    )
                }
                SuaaTab.HISTORY -> {
                    OfflineHistoryScreen(
                        savedScans = savedScans,
                        onSelectRecord = { viewModel.loadHistoricalScan(it) },
                        onDeleteRecord = { viewModel.deleteSavedScan(it) },
                        onClearAll = { viewModel.clearAllHistory() },
                        isHindi = isHindi
                    )
                }
            }
        }
    }
}
