package com.example.ui

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SampleCropData
import com.example.data.alerts.SmartAlertManager
import com.example.data.blur.BlurDetector
import com.example.data.database.AgriDatabase
import com.example.data.database.ScanRecordEntity
import com.example.data.database.ScanRecordRepository
import com.example.data.gemini.GeminiAiService
import com.example.data.model.CarePlan
import com.example.data.model.CapturedAngle
import com.example.data.model.ChatMessage
import com.example.data.model.DiagnosisResult
import com.example.data.model.DiseaseSeverity
import com.example.data.model.PlantAngle
import com.example.data.model.WeatherInfo
import com.example.data.voice.SupportedVoiceLanguage
import com.example.data.voice.TtsSpeechRate
import com.example.data.voice.VoiceAssistantManager
import com.example.data.voice.VoiceLanguages
import com.example.data.weather.WeatherService
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.InputStream

enum class SuaaTab(val label: String, val stepName: String, val subtitle: String) {
    SEE("See", "1. Smart Multi-Angle Camera", "Capture 3-5 views with blur check"),
    UNDERSTAND("Understand", "2. AI & Weather Fusion", "Multimodal pathology & risk reasoning"),
    ACT("Act", "3. Weather-Aware Care Plan", "Actionable irrigation & spray window"),
    ASK("Ask", "4. Voice Assistant", "Push-to-Talk in English & हिन्दी"),
    HISTORY("Offline", "Offline Saved Records", "Cached diagnostic reports & alerts")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val weatherService = WeatherService(application)
    private val geminiService = GeminiAiService()
    private val alertManager = SmartAlertManager(application)
    val voiceManager = VoiceAssistantManager(application)

    private val database = AgriDatabase.getDatabase(application)
    private val repository = ScanRecordRepository(database.scanRecordDao())

    val savedScans: StateFlow<List<ScanRecordEntity>> = repository.allScans
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _currentTab = MutableStateFlow(SuaaTab.SEE)
    val currentTab: StateFlow<SuaaTab> = _currentTab.asStateFlow()

    private val _capturedAngles = MutableStateFlow<Map<PlantAngle, CapturedAngle>>(emptyMap())
    val capturedAngles: StateFlow<Map<PlantAngle, CapturedAngle>> = _capturedAngles.asStateFlow()

    private val _selectedAngle = MutableStateFlow(PlantAngle.LEAF_TOP)
    val selectedAngle: StateFlow<PlantAngle> = _selectedAngle.asStateFlow()

    private val _weatherInfo = MutableStateFlow(WeatherInfo())
    val weatherInfo: StateFlow<WeatherInfo> = _weatherInfo.asStateFlow()

    private val _isWeatherLoading = MutableStateFlow(false)
    val isWeatherLoading: StateFlow<Boolean> = _isWeatherLoading.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _diagnosisResult = MutableStateFlow<DiagnosisResult?>(null)
    val diagnosisResult: StateFlow<DiagnosisResult?> = _diagnosisResult.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                isFromUser = false,
                textEnglish = "Namaste! I am your AgriVision AI Assistant. Ask me anything about your crop, disease prevention, or how today's weather impacts your spraying schedule.",
                textHindi = "नमस्ते! मैं आपका एग्रीविज़न एआई सहायक हूँ। अपनी फसल, रोग निवारण या मौसम के अनुसार छिड़काव के बारे में कुछ भी पूछें।"
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isHindiPreferred = MutableStateFlow(false)
    val isHindiPreferred: StateFlow<Boolean> = _isHindiPreferred.asStateFlow()

    val selectedVoiceLanguage = voiceManager.selectedLanguage
    val ttsSpeechRate = voiceManager.speechRate
    val voiceEngineStatus = voiceManager.engineStatus
    val rmsDb = voiceManager.rmsDb
    val partialSpeechInput = voiceManager.partialSpeechInput
    val speechError = voiceManager.speechError

    private val _userFeedbackNotice = MutableStateFlow<String?>(null)
    val userFeedbackNotice: StateFlow<String?> = _userFeedbackNotice.asStateFlow()

    private val sharedPrefs by lazy {
        getApplication<Application>().getSharedPreferences("agrivision_preferences", Context.MODE_PRIVATE)
    }

    private val _themeMode = MutableStateFlow(
        run {
            val saved = sharedPrefs.getString("pref_theme_mode", ThemeMode.SYSTEM.name)
            try {
                ThemeMode.valueOf(saved ?: ThemeMode.SYSTEM.name)
            } catch (_: Exception) {
                ThemeMode.SYSTEM
            }
        }
    )
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
        sharedPrefs.edit().putString("pref_theme_mode", mode.name).apply()
    }

    fun cycleThemeMode() {
        val nextMode = when (_themeMode.value) {
            ThemeMode.SYSTEM -> ThemeMode.DARK
            ThemeMode.DARK -> ThemeMode.LIGHT
            ThemeMode.LIGHT -> ThemeMode.SYSTEM
        }
        setThemeMode(nextMode)
        val modeLabel = when (nextMode) {
            ThemeMode.SYSTEM -> if (_isHindiPreferred.value) "थीम: सिस्टम अनुसार" else "Theme: System Default"
            ThemeMode.DARK -> if (_isHindiPreferred.value) "थीम: डार्क मोड (Dark)" else "Theme: Dark Mode"
            ThemeMode.LIGHT -> if (_isHindiPreferred.value) "थीम: लाइट मोड (Light)" else "Theme: Light Mode"
        }
        _userFeedbackNotice.value = modeLabel
    }

    init {
        refreshWeather()
        // Pre-populate with 2 crisp sample angles so the user immediately sees the multi-angle interface
        loadSampleAngles(blurryAngle = null)
    }

    fun setTab(tab: SuaaTab) {
        _currentTab.value = tab
    }

    fun selectAngle(angle: PlantAngle) {
        _selectedAngle.value = angle
    }

    fun toggleLanguage() {
        _isHindiPreferred.value = !_isHindiPreferred.value
        val newLang = if (_isHindiPreferred.value) VoiceLanguages.HINDI else VoiceLanguages.ENGLISH
        voiceManager.setLanguage(newLang)
    }

    fun selectVoiceLanguage(language: SupportedVoiceLanguage) {
        voiceManager.setLanguage(language)
        _isHindiPreferred.value = (language != VoiceLanguages.ENGLISH)
        _userFeedbackNotice.value = "Voice Language set to ${language.displayName} (${language.nativeLabel})"
    }

    fun setTtsSpeechRate(rate: TtsSpeechRate) {
        voiceManager.setSpeechRate(rate)
    }

    fun clearFeedbackNotice() {
        _userFeedbackNotice.value = null
    }

    fun refreshWeather() {
        viewModelScope.launch {
            _isWeatherLoading.value = true
            val fetched = weatherService.fetchCurrentWeather()
            _weatherInfo.value = fetched
            _isWeatherLoading.value = false
        }
    }

    fun onImageCaptured(angle: PlantAngle, bitmap: Bitmap) {
        viewModelScope.launch {
            val quality = BlurDetector.analyzeQuality(bitmap)
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream)
            val base64 = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)

            val captured = CapturedAngle(
                angle = angle,
                imagePath = null,
                base64Data = base64,
                qualityCheck = quality
            )

            val updated = _capturedAngles.value.toMutableMap()
            updated[angle] = captured
            _capturedAngles.value = updated

            // If blurry, show helpful prompt
            if (!quality.quality.isAcceptable) {
                _userFeedbackNotice.value = "⚠️ ${angle.title}: ${quality.quality.label}. Hold camera steady for maximum diagnosis precision."
            } else {
                _userFeedbackNotice.value = "✅ ${angle.title} captured with ${quality.sharpnessPercent}% sharpness score."
            }
        }
    }

    fun onUriImageSelected(angle: PlantAngle, uri: Uri) {
        viewModelScope.launch {
            try {
                val context = getApplication<Application>()
                val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                if (bitmap != null) {
                    onImageCaptured(angle, bitmap)
                }
            } catch (e: Exception) {
                _userFeedbackNotice.value = "Failed to load image: ${e.message}"
            }
        }
    }

    fun loadSampleAngles(blurryAngle: PlantAngle? = null) {
        val map = mutableMapOf<PlantAngle, CapturedAngle>()
        PlantAngle.values().forEach { angle ->
            val isBlur = (angle == blurryAngle)
            map[angle] = SampleCropData.createSampleAngle(angle, isBlurry = isBlur)
        }
        _capturedAngles.value = map
        _userFeedbackNotice.value = "Loaded 5 multi-angle plant photos with real-time blur diagnostics."
    }

    fun removeCapturedAngle(angle: PlantAngle) {
        val updated = _capturedAngles.value.toMutableMap()
        updated.remove(angle)
        _capturedAngles.value = updated
    }

    fun runUnderstandAnalysis() {
        val count = _capturedAngles.value.size
        if (count < 1) {
            _userFeedbackNotice.value = "Please capture at least 1-3 plant angles before diagnosis."
            return
        }

        viewModelScope.launch {
            _isAnalyzing.value = true
            _userFeedbackNotice.value = "Gemini Multimodal AI is analyzing $count angles and fusing live weather..."

            val anglesList = _capturedAngles.value.values.toList()
            val result = geminiService.analyzePlantAndWeather(anglesList, _weatherInfo.value)
            _diagnosisResult.value = result
            _isAnalyzing.value = false

            // Auto-cache in local Room DB for offline mode
            saveDiagnosisLocally(result)

            // Transition to Understand tab
            _currentTab.value = SuaaTab.UNDERSTAND
            _userFeedbackNotice.value = "Diagnosis complete: ${result.primaryDisease} (${result.confidencePercent}% confidence)."
        }
    }

    private suspend fun saveDiagnosisLocally(result: DiagnosisResult) {
        val entity = ScanRecordEntity(
            plantName = result.plantName,
            diseaseName = result.primaryDisease,
            diseaseNameHindi = result.primaryDiseaseHindi,
            confidencePercent = result.confidencePercent,
            severity = result.severity.name,
            pathogenCategory = result.pathogenCategory,
            temperature = _weatherInfo.value.temperatureCelsius,
            humidity = _weatherInfo.value.humidityPercent,
            weatherCondition = _weatherInfo.value.weatherCondition,
            rainForecastMm = _weatherInfo.value.rainForecastNext24hMm,
            irrigationAdvice = result.carePlan.irrigationAdvice,
            irrigationAdviceHindi = result.carePlan.irrigationAdviceHindi,
            sprayRecommendation = result.carePlan.sprayWindowRecommendation,
            remediesJson = result.carePlan.organicRemedies.joinToString("\n"),
            observationsJson = result.keyObservations.joinToString("\n"),
            anglesCount = result.anglesAnalyzedCount
        )
        repository.insertScan(entity)
    }

    fun triggerSmartNotification() {
        val weather = _weatherInfo.value
        val diagnosis = _diagnosisResult.value
        if (weather.shouldSkipWatering) {
            alertManager.sendRainIrrigationAlert(weather.rainForecastNext24hMm, weather.precipitationChance)
            _userFeedbackNotice.value = "📢 Push notification sent: Rain Alert - Skip Irrigation."
        } else if (diagnosis != null && diagnosis.severity == DiseaseSeverity.SEVERE) {
            alertManager.sendDiseaseOutbreakWarning(diagnosis.primaryDisease, diagnosis.severity.label)
            _userFeedbackNotice.value = "📢 Push notification sent: Spore Proliferation Alert."
        } else {
            alertManager.sendOptimalSprayAlert(weather.sprayWindowRecommendation)
            _userFeedbackNotice.value = "📢 Push notification sent: Optimal Spray Window."
        }
    }

    fun sendVoiceOrTextMessage(query: String) {
        if (query.isBlank()) return

        val userMsg = ChatMessage(
            isFromUser = true,
            textEnglish = query,
            textHindi = query
        )
        _chatMessages.value = _chatMessages.value + userMsg

        viewModelScope.launch {
            val (respEng, respHin) = geminiService.answerFarmerQuestion(
                question = query,
                currentDiagnosis = _diagnosisResult.value,
                weather = _weatherInfo.value,
                preferredLanguageHindi = _isHindiPreferred.value
            )

            val aiMsg = ChatMessage(
                isFromUser = false,
                textEnglish = respEng,
                textHindi = respHin
            )
            _chatMessages.value = _chatMessages.value + aiMsg

            // Speak response via native TTS engine
            val currentLang = voiceManager.selectedLanguage.value
            val spokenText = if (currentLang != VoiceLanguages.ENGLISH) {
                respHin.ifBlank { respEng }
            } else {
                respEng
            }
            voiceManager.speak(spokenText, language = currentLang)
        }
    }

    fun speakMessage(message: ChatMessage) {
        val currentLang = voiceManager.selectedLanguage.value
        val text = if (currentLang != VoiceLanguages.ENGLISH) {
            message.textHindi.ifBlank { message.textEnglish }
        } else {
            message.textEnglish
        }
        voiceManager.speak(text, language = currentLang)
    }

    fun deleteSavedScan(id: Long) {
        viewModelScope.launch {
            repository.deleteScanById(id)
            _userFeedbackNotice.value = "Record removed from offline cache."
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
            _userFeedbackNotice.value = "Offline cache cleared."
        }
    }

    fun loadHistoricalScan(record: ScanRecordEntity) {
        val carePlan = CarePlan(
            irrigationAdvice = record.irrigationAdvice,
            irrigationAdviceHindi = record.irrigationAdviceHindi,
            sprayWindowRecommendation = record.sprayRecommendation,
            organicRemedies = record.remediesJson.split("\n").filter { it.isNotBlank() },
            chemicalTreatments = listOf("Consult local agronomist for dosage adjustments"),
            preventativeMeasures = listOf("Maintain airflow and drip irrigation")
        )

        val severity = try {
            DiseaseSeverity.valueOf(record.severity)
        } catch (_: Exception) {
            DiseaseSeverity.MODERATE
        }

        _diagnosisResult.value = DiagnosisResult(
            plantName = record.plantName,
            primaryDisease = record.diseaseName,
            primaryDiseaseHindi = record.diseaseNameHindi,
            confidencePercent = record.confidencePercent,
            severity = severity,
            pathogenCategory = record.pathogenCategory,
            keyObservations = record.observationsJson.split("\n").filter { it.isNotBlank() },
            weatherRiskFusion = "Historical Weather Record: ${record.temperature}°C, ${record.humidity}% humidity, ${record.rainForecastMm}mm rain.",
            carePlan = carePlan,
            anglesAnalyzedCount = record.anglesCount
        )

        _currentTab.value = SuaaTab.UNDERSTAND
        _userFeedbackNotice.value = "Loaded cached scan for ${record.diseaseName} (Offline Mode)."
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.shutdown()
    }
}
