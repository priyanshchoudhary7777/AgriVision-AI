package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BlurQuality
import com.example.data.model.DiseaseSeverity
import com.example.data.model.QualityCheckResult
import com.example.data.model.WeatherInfo
import com.example.ui.SuaaTab
import com.example.ui.theme.AgriAmber
import com.example.ui.theme.AgriGold
import com.example.ui.theme.AgriGreenDark
import com.example.ui.theme.AgriGreenLight
import com.example.ui.theme.AgriGreenMint
import com.example.ui.theme.AgriGreenPale
import com.example.ui.theme.AgriGreenPrimary
import com.example.ui.theme.AgriRedAlert
import com.example.ui.theme.ThemeMode

@Composable
fun SuaaAppHeader(
    currentTab: SuaaTab,
    isHindi: Boolean,
    onToggleLanguage: () -> Unit,
    weather: WeatherInfo,
    isWeatherLoading: Boolean,
    onRefreshWeather: () -> Unit,
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    onCycleThemeMode: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isDark = isSystemInDarkTheme() || themeMode == ThemeMode.DARK
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val isGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (isGranted) {
            onRefreshWeather()
        }
    }

    val triggerWeatherRefresh = {
        val hasFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (hasFine || hasCoarse) {
            onRefreshWeather()
        } else {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    Surface(
        color = if (isDark) Color(0xFF10281C) else AgriGreenDark,
        tonalElevation = 6.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(AgriGreenPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "🌱",
                            fontSize = 20.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "AgriVision AI",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                ),
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = AgriGreenLight.copy(alpha = 0.25f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "SUAA",
                                    color = AgriGreenPale,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = if (isHindi) "सी • समझें • कार्य • पूछें (पौधों की एआई देखभाल)" else "See • Understand • Act • Ask",
                            style = MaterialTheme.typography.bodySmall,
                            color = AgriGreenPale.copy(alpha = 0.85f),
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Theme toggle chip
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White.copy(alpha = 0.15f),
                        modifier = Modifier
                            .testTag("theme_toggle")
                            .clickable { onCycleThemeMode() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = when (themeMode) {
                                    ThemeMode.SYSTEM -> Icons.Default.BrightnessAuto
                                    ThemeMode.DARK -> Icons.Default.DarkMode
                                    ThemeMode.LIGHT -> Icons.Default.LightMode
                                },
                                contentDescription = "Toggle theme mode",
                                tint = Color.White,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (themeMode) {
                                    ThemeMode.SYSTEM -> if (isHindi) "ऑटो" else "Auto"
                                    ThemeMode.DARK -> if (isHindi) "डार्क" else "Dark"
                                    ThemeMode.LIGHT -> if (isHindi) "लाइट" else "Light"
                                },
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Language toggle chip
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White.copy(alpha = 0.15f),
                        modifier = Modifier
                            .testTag("language_toggle")
                            .clickable { onToggleLanguage() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (isHindi) "🇮🇳 हिन्दी" else "🌐 EN",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }


            Spacer(modifier = Modifier.height(8.dp))

            // Weather fusion status ticker
            Surface(
                color = Color.Black.copy(alpha = 0.25f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { triggerWeatherRefresh() }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "GPS",
                            tint = AgriGreenLight,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${weather.temperatureCelsius}°C  •  ${weather.humidityPercent}% Hum  •  ${weather.weatherCondition}",
                            color = Color.White.copy(alpha = 0.92f),
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }

                    if (isWeatherLoading) {
                        CircularProgressIndicator(
                            strokeWidth = 2.dp,
                            color = AgriGreenLight,
                            modifier = Modifier.size(16.dp)
                        )
                    } else {
                        IconButton(
                            onClick = triggerWeatherRefresh,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh Weather",
                                tint = AgriGreenPale,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QualityCheckBadge(
    quality: QualityCheckResult,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    val (bg, textColor, iconText) = when (quality.quality) {
        BlurQuality.SHARP -> if (isDark) {
            Triple(Color(0xFF183B25), AgriGreenLight, "✓ Sharp")
        } else {
            Triple(AgriGreenPale, AgriGreenDark, "✓ Sharp")
        }
        BlurQuality.ACCEPTABLE -> if (isDark) {
            Triple(Color(0xFF3B2A05), AgriGold, "⚡ Acceptable")
        } else {
            Triple(Color(0xFFFFF3CD), Color(0xFF856404), "⚡ Acceptable")
        }
        BlurQuality.BLURRY -> if (isDark) {
            Triple(Color(0xFF451117), Color(0xFFFF8A80), "⚠ Blurry")
        } else {
            Triple(Color(0xFFF8D7DA), AgriRedAlert, "⚠ Blurry")
        }
    }

    Surface(
        color = bg,
        shape = RoundedCornerShape(6.dp),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = "$iconText (${quality.sharpnessPercent}%)",
                color = textColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun SeverityBadge(
    severity: DiseaseSeverity,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    val (bgColor, textColor) = when (severity) {
        DiseaseSeverity.HEALTHY -> if (isDark) Pair(Color(0xFF183B25), AgriGreenLight) else Pair(AgriGreenPale, AgriGreenDark)
        DiseaseSeverity.LOW -> if (isDark) Pair(Color(0xFF153322), AgriGreenMint) else Pair(Color(0xFFE8F5E9), AgriGreenPrimary)
        DiseaseSeverity.MODERATE -> if (isDark) Pair(Color(0xFF3E2805), AgriAmber) else Pair(Color(0xFFFFF3E0), Color(0xFFB74D00))
        DiseaseSeverity.SEVERE -> if (isDark) Pair(Color(0xFF451117), Color(0xFFFF8A80)) else Pair(Color(0xFFFFEBEE), AgriRedAlert)
        DiseaseSeverity.CRITICAL -> if (isDark) Pair(Color(0xFF550A14), Color(0xFFFFB4AB)) else Pair(Color(0xFF2C0B0E), Color(0xFFFF8A80))
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(6.dp),
        modifier = modifier
    ) {
        Text(
            text = severity.label,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun WeatherSummaryCard(
    weather: WeatherInfo,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Cloud,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Real-Time Weather Fusion",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Surface(
                    color = if (weather.isHighDiseaseRisk) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = if (weather.isHighDiseaseRisk) "⚠️ High Spore Risk" else "Normal Microclimate",
                        color = if (weather.isHighDiseaseRisk) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }


            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                WeatherMetric(
                    icon = Icons.Default.Thermostat,
                    value = "${weather.temperatureCelsius}°C",
                    label = "Temp"
                )
                WeatherMetric(
                    icon = Icons.Default.WaterDrop,
                    value = "${weather.humidityPercent}%",
                    label = "Humidity"
                )
                WeatherMetric(
                    icon = Icons.Default.Cloud,
                    value = "${weather.rainForecastNext24hMm} mm",
                    label = "24h Rain"
                )
                WeatherMetric(
                    icon = Icons.Default.Air,
                    value = "${weather.windSpeedKmh} km/h",
                    label = "Wind"
                )
            }
        }
    }
}

@Composable
private fun WeatherMetric(
    icon: ImageVector,
    value: String,
    label: String
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = AgriGreenPrimary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
