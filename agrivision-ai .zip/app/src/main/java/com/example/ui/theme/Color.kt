package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Agricultural Greens
val AgriGreenDark = Color(0xFF1B4332)
val AgriGreenPrimary = Color(0xFF2D6A4F)
val AgriGreenMedium = Color(0xFF40916C)
val AgriGreenLight = Color(0xFF52B788)
val AgriGreenMint = Color(0xFF74C69D)
val AgriGreenPale = Color(0xFFD8F3DC)
val AgriGreenContainer = Color(0xFFE8F5E9)

// Accent Warm Gold & Sunset Alert
val AgriGold = Color(0xFFE9C46A)
val AgriAmber = Color(0xFFF4A261)
val AgriTerracotta = Color(0xFFE76F51)
val AgriRedAlert = Color(0xFFD90429)

// Neutral & Backgrounds
val AgriCanvasLight = Color(0xFFF7FAF7)
val AgriSurfaceLight = Color(0xFFFFFFFF)
val AgriSurfaceVariant = Color(0xFFEDF2ED)
val AgriTextPrimary = Color(0xFF132A13)
val AgriTextSecondary = Color(0xFF3F4E3F)
val AgriTextMuted = Color(0xFF718271)

// Dark Theme Variants
val AgriCanvasDark = Color(0xFF0D1B13)
val AgriSurfaceDark = Color(0xFF15261C)
val AgriSurfaceDarkVariant = Color(0xFF1F3528)
val AgriSurfaceDarkContainer = Color(0xFF1B2F23)
val AgriSurfaceDarkHigh = Color(0xFF233B2D)
val AgriTextPrimaryDark = Color(0xFFE8F5E9)
val AgriTextSecondaryDark = Color(0xFFB7D5BF)
val AgriTextMutedDark = Color(0xFF8BA593)

// Dark Theme Accent Containers
val AgriAmberDarkContainer = Color(0xFF332005)
val AgriAmberDarkText = Color(0xFFFFD54F)
val AgriRedDarkContainer = Color(0xFF3E1217)
val AgriRedDarkText = Color(0xFFFF8A80)
