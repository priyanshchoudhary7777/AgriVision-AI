package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

enum class ThemeMode(val title: String, val titleHindi: String) {
    SYSTEM("System Default", "सिस्टम अनुसार"),
    LIGHT("Light Theme", "लाइट थीम"),
    DARK("Dark Theme", "डार्क थीम")
}

private val DarkColorScheme = darkColorScheme(
    primary = AgriGreenLight,
    onPrimary = Color(0xFF00381F),
    primaryContainer = AgriGreenDark,
    onPrimaryContainer = AgriGreenPale,
    secondary = AgriAmber,
    onSecondary = Color(0xFF432B00),
    secondaryContainer = AgriAmberDarkContainer,
    onSecondaryContainer = AgriAmberDarkText,
    tertiary = AgriGreenMint,
    onTertiary = Color(0xFF003822),
    tertiaryContainer = Color(0xFF1B3D2B),
    onTertiaryContainer = Color(0xFFA4F2C5),
    background = AgriCanvasDark,
    onBackground = AgriTextPrimaryDark,
    surface = AgriSurfaceDark,
    onSurface = AgriTextPrimaryDark,
    surfaceVariant = AgriSurfaceDarkVariant,
    onSurfaceVariant = AgriTextSecondaryDark,
    surfaceContainer = AgriSurfaceDarkContainer,
    surfaceContainerHigh = AgriSurfaceDarkHigh,
    surfaceContainerHighest = Color(0xFF2B4434),
    outline = Color(0xFF4B6B56),
    outlineVariant = Color(0xFF294132),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = AgriRedDarkContainer,
    onErrorContainer = AgriRedDarkText
)

private val LightColorScheme = lightColorScheme(
    primary = AgriGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = AgriGreenPale,
    onPrimaryContainer = AgriGreenDark,
    secondary = AgriAmber,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFF3E0),
    onSecondaryContainer = Color(0xFF7C3600),
    tertiary = AgriGold,
    onTertiary = Color.Black,
    tertiaryContainer = Color(0xFFE8F5E9),
    onTertiaryContainer = AgriGreenDark,
    background = AgriCanvasLight,
    onBackground = AgriTextPrimary,
    surface = AgriSurfaceLight,
    onSurface = AgriTextPrimary,
    surfaceVariant = AgriSurfaceVariant,
    onSurfaceVariant = AgriTextSecondary,
    surfaceContainer = Color(0xFFF2F7F2),
    surfaceContainerHigh = Color(0xFFE8EFE8),
    surfaceContainerHighest = Color(0xFFDEE7DE),
    outline = AgriTextMuted,
    outlineVariant = Color(0xFFC7D5C7),
    error = AgriRedAlert,
    onError = Color.White,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002)
)

@Composable
fun MyApplicationTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    darkTheme: Boolean = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    },
    dynamicColor: Boolean = false, // Keep intentional agrarian branding
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

