package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.SampleCropData
import com.example.data.blur.BlurDetector
import com.example.data.model.BlurQuality
import com.example.data.model.PlantAngle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("AgriVision AI", appName)
  }

  @Test
  fun `blur detector identifies sharp image`() {
    val angle = SampleCropData.createSampleAngle(PlantAngle.LEAF_TOP, isBlurry = false)
    assertNotNull(angle.qualityCheck)
    assertTrue(angle.qualityCheck!!.sharpnessPercent > 50)
  }

  @Test
  fun `blur detector identifies blurry image`() {
    val angle = SampleCropData.createSampleAngle(PlantAngle.LEAF_TOP, isBlurry = true)
    assertNotNull(angle.qualityCheck)
    assertTrue(angle.qualityCheck!!.varianceScore < 150)
  }

  @Test
  fun `verify multilingual voice languages and sample prompts`() {
    val languages = com.example.data.voice.VoiceLanguages.ALL_LANGUAGES
    assertTrue(languages.isNotEmpty())
    assertTrue(languages.any { it.code == "en-US" })
    assertTrue(languages.any { it.code == "hi-IN" })
    assertTrue(languages.any { it.code == "pa-IN" })

    val hindi = com.example.data.voice.VoiceLanguages.HINDI
    assertEquals("hi-IN", hindi.code)
    assertTrue(hindi.samplePrompts.isNotEmpty())
  }

  @Test
  fun `verify speech recognizer intent creation with target language`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val voiceManager = com.example.data.voice.VoiceAssistantManager(context)
    val punjabi = com.example.data.voice.VoiceLanguages.PUNJABI
    val intent = voiceManager.createSpeechRecognizerIntent(punjabi)

    assertEquals(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH, intent.action)
    assertEquals("pa-IN", intent.getStringExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE))
    assertTrue(intent.getBooleanExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, false))
    voiceManager.shutdown()
  }

  @Test
  fun `verify required runtime permissions declared in manifest`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val packageInfo = context.packageManager.getPackageInfo(
      context.packageName,
      android.content.pm.PackageManager.GET_PERMISSIONS
    )
    val permissions = packageInfo.requestedPermissions?.toList() ?: emptyList()

    assertTrue(permissions.contains(android.Manifest.permission.CAMERA))
    assertTrue(permissions.contains(android.Manifest.permission.ACCESS_FINE_LOCATION))
    assertTrue(permissions.contains(android.Manifest.permission.ACCESS_COARSE_LOCATION))
    assertTrue(permissions.contains(android.Manifest.permission.RECORD_AUDIO))
  }
}

